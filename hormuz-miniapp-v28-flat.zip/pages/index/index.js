// pages/index/index.js
const DATA_URL_CN = 'https://hz.clawx.gold/hormuz-data.json' // 大陆优先（自有域名）
const DATA_URL = 'https://ancient-union-867e.tcwkid.workers.dev' // CF Worker 备用
const DATA_URL_FALLBACK = 'https://gist.githubusercontent.com/tcwkid/3c7ac2f49b0cb343394dec4ae5b810e8/raw/hormuz-data.json' // 海外兜底
const NORMAL = 135

// 冲突等级定义
const CONFLICT_LEVELS = [
  { id: 1, icon: '🕊️', name: '外交接触', desc: '双方通过外交渠道磋商，无军事行动', color: '#4a9eff', pct: 15 },
  { id: 2, icon: '⚠️', name: '军事威胁', desc: '军队集结、航母部署，谈判破裂风险上升', color: '#f0c040', pct: 35 },
  { id: 3, icon: '🔒', name: '封锁对峙', desc: '美军封锁伊朗港口，霍尔木兹通行骤降，谈判陷僵局', color: '#ff8c42', pct: 62 },
  { id: 4, icon: '💥', name: '军事打击', desc: '双方爆发直接武装冲突，导弹/无人机互袭', color: '#f85149', pct: 82 },
  { id: 5, icon: '☢️', name: '全面战争', desc: '大规模战争爆发，霍尔木兹完全封闭', color: '#ff3b5c', pct: 100 }
]

const EMBED_DATA = {"lastUpdate":"--","flashNews":"🔴 加载中｜正在拉取实时数据","shipCount":15,"shipChg":"0","oilWti":0,"oilWtiChgRaw":0,"oilWtiChg":"0","goldPrice":0,"goldChgRaw":0,"goldChg":"0","congestion":11,"congestionNote":"数据加载中","lngStatus":"❌ 封锁中","lngNote":"数据加载中","barData":[],"tableRows":[],"events":[],"insightText":"数据加载中，请稍候...","insightTime":""};

// 内置历史价格（与H5一致）
const BUILTIN_PRICES = [
  { date: '3/1', wti: 72.3, gold: 3820 },
  { date: '3/5', wti: 88.5, gold: 3980 },
  { date: '3/10', wti: 98.2, gold: 4150 },
  { date: '3/15', wti: 105.4, gold: 4320 },
  { date: '3/20', wti: 109.8, gold: 4480 },
  { date: '3/25', wti: 111.2, gold: 4580 },
  { date: '3/30', wti: 112.5, gold: 4650 },
  { date: '4/4', wti: 113.1, gold: 4700 },
  { date: '4/7', wti: 92.6, gold: 4800 },
  { date: '4/10', wti: 93.4, gold: 4780 },
  { date: '4/13', wti: 105.2, gold: 4710 }
]

Page({
  data: {
    // 基础信息
    countdown: '--:--:--',
    lastUpdate: '加载中...',
    flashNews: '数据加载中...',
    loading: true,

    // 6个指标卡
    shipCount: '--',
    shipChg: '0',
    shipChgDir: 'down',
    oilWti: '--',
    oilWtiChg: '--',
    oilWtiDir: 'down',
    goldPrice: '--',
    goldChg: '--',
    goldDir: 'up',
    recoveryPct: '--',
    recoveryNote: '战前正常 135艘/天',
    lngStatus: '--',
    lngNote: '卡塔尔/阿联酋LNG动态',
    lngPassed: false,
    // 冲突卡片
    conflictName: '封锁对峙',
    conflictLevel: 3,
    conflictColor: '#ff8c42',
    conflictBarPct: 62,
    conflictDesc: '美军封锁伊朗港口，霍尔木兹通行骤降',

    // 海峡示意图底部
    straitStatusText: '封锁状态：--',
    straitStatusColor: '#f85149',

    // 柱状图
    barData: [],
    barMaxLabel: 10,

    // 冲突仪表盘
    conflictLevels: CONFLICT_LEVELS,
    conflictBarFillPct: 0,
    conflictFullDesc: '',

    // 变化明细
    tableRows: [],

    // 关键事件
    events: [],

    // 进度条解读
    insightText: '',
    insightLines: [],
    insightTime: '',
    insightPlaceholder: '加载中...',

    // 访问统计
    visitPV: '--',
    visitUV: '--'
  },

  _timer: null,
  _countdownSec: 3600,

  onLoad() {
    // 先用内嵌数据秒开（解决国内无法访问workers.dev的问题）
    this.applyData(EMBED_DATA)
    this.fetchAllData()
    this.startCountdown()
    this.trackVisit()
  },

  onUnload() {
    if (this._timer) clearInterval(this._timer)
  },

  onPullDownRefresh() {
    this.fetchAllData(() => {
      wx.stopPullDownRefresh()
      wx.showToast({ title: '已更新', icon: 'success', duration: 800 })
    })
  },

  fetchAllData(callback) {
    const self = this
    const urls = [
      DATA_URL_CN + '?t=' + Date.now(),
      DATA_URL + '?t=' + Date.now(),
      DATA_URL_FALLBACK + '?t=' + Date.now()
    ]

    function tryUrl(idx) {
      if (idx >= urls.length) {
        self.setData({ insightPlaceholder: '网络异常，已使用本地缓存数据', loading: false })
        if (callback) callback()
        return
      }

      wx.request({
        url: urls[idx],
        method: 'GET',
        timeout: 15000,
        success(res) {
          if (res.statusCode === 200 && res.data) {
            self.applyData(res.data)
            if (callback) callback()
          } else {
            tryUrl(idx + 1)
          }
        },
        fail() {
          tryUrl(idx + 1)
        }
      })
    }

    tryUrl(0)
  },

  applyData(d) {
    // 涨跌计算
    const oilChgRaw = parseFloat(d.oilWtiChgRaw) || parseFloat(d.oilWtiChg) || 0
    const oilDir = oilChgRaw >= 0 ? 'up' : 'down'
    const oilChgAbs = Math.abs(oilChgRaw).toFixed(2)

    const goldChgRaw = parseFloat(d.goldChgRaw) || parseFloat(d.goldChg) || 0
    const goldDir = goldChgRaw >= 0 ? 'up' : 'down'
    const goldChgAbs = Math.abs(goldChgRaw).toFixed(2)

    const shipChg = d.shipChg || '0'
    const shipChgNum = parseInt(shipChg) || 0
    const shipChgDir = shipChgNum >= 0 ? 'up' : 'down'

    const shipCount = d.shipCount || 0

    // 恢复度 = shipCount / 135 * 100
    const recoveryPct = shipCount ? Math.round(shipCount / NORMAL * 100) : 0

    // 海峡底部状态
    const isBlocked = recoveryPct < 10
    const straitStatusText = isBlocked
      ? '🔴 封锁中 · 仅 ' + shipCount + ' 艘通过 · 恢复度 ' + recoveryPct + '%'
      : '🟡 受限通行 · 今日 ' + shipCount + ' 艘 · 战前正常 ' + NORMAL + ' 艘'
    const straitStatusColor = isBlocked ? '#f85149' : '#d29922'

    // 拥堵Note处理
    const congestionNote = d.congestionNote || ''
    const recoveryNote = congestionNote.length > 40 ? congestionNote.slice(0, 40) + '…' : (congestionNote || '战前正常 135艘/天')

    // 冲突等级
    const conflictLevel = d.conflictLevel ? parseInt(d.conflictLevel) : 3
    const curConflict = CONFLICT_LEVELS.find(l => l.id === conflictLevel) || CONFLICT_LEVELS[2]

    // 柱状图
    const barData = d.barData || []
    const maxShips = barData.reduce((m, b) => Math.max(m, b.totalH || 0), 0)
    const barMaxLabel = Math.max(Math.ceil(maxShips / 5) * 5, 10)
    const rpxPerShip = 200 / barMaxLabel
    const barDataCalc = barData.map(b => ({
      ...b,
      totalHPx: Math.max(Math.round((b.totalH || 0) * rpxPerShip), b.totalH > 0 ? 2 : 0),
      oilHPx: Math.max(Math.round((b.oilH || 0) * rpxPerShip), b.oilH > 0 ? 1 : 0)
    }))

    // events
    const events = (d.events || []).map(e => ({
      ...e,
      detail: e.detail || e.desc || ''
    }))

    // LNG
    const lngPassed = (d.lngStatus || '').indexOf('✅') >= 0 || (d.lngStatus || '').indexOf('通过') >= 0
    const lngNote = d.lngNote || ''

    this.setData({
      lastUpdate: d.lastUpdate || '--',
      flashNews: d.flashNews || '',
      shipCount: shipCount || '--',
      shipChg: shipChg,
      shipChgDir: shipChgDir,
      oilWti: d.oilWti || '--',
      oilWtiChg: oilChgAbs,
      oilWtiDir: oilDir,
      goldPrice: d.goldPrice || '--',
      goldChg: goldChgAbs,
      goldDir: goldDir,
      recoveryPct: recoveryPct,
      recoveryNote: recoveryNote,
      recoveryNoteColor: recoveryPct < 10 ? '#f85149' : '#8b949e',
      lngStatus: d.lngStatus || '--',
      lngNote: lngNote.length > 40 ? lngNote.slice(0, 40) + '…' : lngNote,
      lngPassed: lngPassed,

      // 冲突卡片
      conflictName: curConflict.name,
      conflictLevel: conflictLevel,
      conflictColor: curConflict.color,
      conflictBarPct: curConflict.pct,
      conflictDesc: curConflict.desc.length > 22 ? curConflict.desc.slice(0, 22) + '…' : curConflict.desc,

      // 海峡状态
      straitStatusText: straitStatusText,
      straitStatusColor: straitStatusColor,

      // 柱状图
      barData: barDataCalc,
      barMaxLabel: barMaxLabel,

      // 冲突仪表盘
      conflictLevels: CONFLICT_LEVELS.map(l => ({
        ...l,
        active: l.id === conflictLevel
      })),
      conflictBarFillPct: curConflict.pct,
      conflictFullDesc: curConflict.desc + ' · 当前 L' + conflictLevel + '·' + curConflict.name,

      // 变化明细
      tableRows: (d.tableRows || []).map((row, i, arr) => {
        const shipVal = row.ships || row.avg || row.count || 0
        const shipNum = parseFloat(shipVal) || 0
        const pctOfNormal = Math.round(shipNum / NORMAL * 100)
        const isLatest = i === arr.length - 1
        const rawChg = row.chg || row.warChg || 0
        const diff = parseFloat(rawChg) || 0
        return {
          ...row,
          shipVal: shipVal,
          pctOfNormal: pctOfNormal,
          barPct: Math.min(pctOfNormal, 100),
          barColor: isLatest ? '#3fb950' : (pctOfNormal < 10 ? '#f85149' : '#58a6ff'),
          isLatest: isLatest,
          diffStr: (diff >= 0 ? '▲ +' : '▼ ') + Math.abs(diff),
          diffClass: diff >= 0 ? 'up' : 'down',
          valColor: isLatest ? '#3fb950' : '#e6edf3'
        }
      }),

      // 价格走势
      // 价格走势改用Canvas绘制

      // 事件
      events: events,

      // 进度条解读
      insightText: d.insightText || '',
      insightLines: (d.insightText || '').split('\n'),
      insightTime: d.insightTime || '',
      insightPlaceholder: '暂无内容',
      loading: false
    })

    // 延迟绘制Canvas图表（等setData渲染完）
    setTimeout(() => { this.drawPriceChart(d) }, 300)
  },

  startCountdown() {
    this._countdownSec = 3600
    this._timer = setInterval(() => {
      this._countdownSec -= 1
      if (this._countdownSec <= 0) {
        this._countdownSec = 3600
        this.fetchAllData()
      }
      const h = Math.floor(this._countdownSec / 3600)
      const m = Math.floor((this._countdownSec % 3600) / 60)
      const s = this._countdownSec % 60
      this.setData({
        countdown: String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0')
      })
    }, 1000)
  },

  onShareAppMessage() {
    const shipCount = this.data.shipCount || '--'
    const oilWti = this.data.oilWti || '--'
    const oilDir = this.data.oilWtiDir === 'up' ? '↑' : '↓'
    const lngPassed = this.data.lngPassed

    const title = lngPassed
      ? '🚨 终极信号！LNG船穿越霍尔木兹｜原油$' + oilWti + oilDir + '｜进度条'
      : '🔥 霍尔木兹封锁实况｜今日' + shipCount + '艘｜原油$' + oilWti + oilDir + '｜进度条'

    return {
      title: title,
      path: '/pages/index/index',
      imageUrl: 'https://picture-search.skywork.ai/skills/upload/2026-04-16/7bba1f32e1d54f72b67cef1cfb6b0247_23aff.png'
    }
  },

  onShareTimeline() {
    const shipCount = this.data.shipCount || '--'
    const oilWti = this.data.oilWti || '--'
    const oilDir = this.data.oilWtiDir === 'up' ? '↑' : '↓'
    return {
      title: '🔥 霍尔木兹封锁实况｜今日' + shipCount + '艘｜原油$' + oilWti + oilDir + '｜进度条追踪',
      imageUrl: 'https://picture-search.skywork.ai/skills/upload/2026-04-16/7bba1f32e1d54f72b67cef1cfb6b0247_23aff.png'
    }
  },

  drawPriceChart(d) {
    const self = this
    const query = wx.createSelectorQuery()
    query.select('#priceCanvas')
      .fields({ node: true, size: true })
      .exec(function(res) {
        if (!res || !res[0]) return
        const canvas = res[0].node
        const ctx = canvas.getContext('2d')
        const dpr = wx.getWindowInfo().pixelRatio || 2
        const width = res[0].width
        const height = res[0].height
        canvas.width = width * dpr
        canvas.height = height * dpr
        ctx.scale(dpr, dpr)

        // 拼接数据
        let allPrices = [...BUILTIN_PRICES]
        if (d && d.oilWti) {
          const dateStr = (d.lastUpdate || '').slice(5, 10).replace('-', '/') || '今日'
          allPrices.push({ date: dateStr, wti: d.oilWti, gold: d.goldPrice || null })
        }

        const wtiVals = allPrices.map(function(p){ return p.wti }).filter(function(v){ return v != null })
        const goldVals = allPrices.map(function(p){ return p.gold }).filter(function(v){ return v != null })
        const wtiMin = Math.floor(Math.min.apply(null, wtiVals) / 10) * 10 - 5
        const wtiMax = Math.ceil(Math.max.apply(null, wtiVals) / 10) * 10 + 5
        const goldMin = Math.floor(Math.min.apply(null, goldVals) / 100) * 100 - 100
        const goldMax = Math.ceil(Math.max.apply(null, goldVals) / 100) * 100 + 100

        // 绘图区域（留出轴标签空间）
        const padLeft = 40
        const padRight = 45
        const padTop = 10
        const padBottom = 30
        const chartW = width - padLeft - padRight
        const chartH = height - padTop - padBottom

        // 背景
        ctx.clearRect(0, 0, width, height)

        // 网格线
        ctx.strokeStyle = '#21262d'
        ctx.lineWidth = 0.5
        for (var g = 0; g <= 4; g++) {
          var gy = padTop + chartH * g / 4
          ctx.beginPath()
          ctx.moveTo(padLeft, gy)
          ctx.lineTo(width - padRight, gy)
          ctx.stroke()
        }

        // 计算点位
        var n = allPrices.length
        var stepX = n > 1 ? chartW / (n - 1) : chartW

        function wtiToY(v) { return padTop + chartH - (v - wtiMin) / (wtiMax - wtiMin) * chartH }
        function goldToY(v) { return padTop + chartH - (v - goldMin) / (goldMax - goldMin) * chartH }

        // 画WTI折线
        ctx.strokeStyle = '#f0a500'
        ctx.lineWidth = 2
        ctx.lineJoin = 'round'
        ctx.beginPath()
        var started = false
        for (var i = 0; i < n; i++) {
          if (allPrices[i].wti == null) continue
          var px = padLeft + i * stepX
          var py = wtiToY(allPrices[i].wti)
          if (!started) { ctx.moveTo(px, py); started = true }
          else { ctx.lineTo(px, py) }
        }
        ctx.stroke()

        // WTI面积填充
        ctx.fillStyle = 'rgba(240,165,0,0.08)'
        ctx.beginPath()
        started = false
        var firstX = 0, lastX = 0
        for (var i = 0; i < n; i++) {
          if (allPrices[i].wti == null) continue
          var px = padLeft + i * stepX
          var py = wtiToY(allPrices[i].wti)
          if (!started) { firstX = px; ctx.moveTo(px, py); started = true }
          else { ctx.lineTo(px, py) }
          lastX = px
        }
        ctx.lineTo(lastX, padTop + chartH)
        ctx.lineTo(firstX, padTop + chartH)
        ctx.closePath()
        ctx.fill()

        // 画黄金折线
        ctx.strokeStyle = '#58a6ff'
        ctx.lineWidth = 2
        ctx.beginPath()
        started = false
        for (var i = 0; i < n; i++) {
          if (allPrices[i].gold == null) continue
          var px = padLeft + i * stepX
          var py = goldToY(allPrices[i].gold)
          if (!started) { ctx.moveTo(px, py); started = true }
          else { ctx.lineTo(px, py) }
        }
        ctx.stroke()

        // 黄金面积填充
        ctx.fillStyle = 'rgba(88,166,255,0.06)'
        ctx.beginPath()
        started = false
        firstX = 0; lastX = 0
        for (var i = 0; i < n; i++) {
          if (allPrices[i].gold == null) continue
          var px = padLeft + i * stepX
          var py = goldToY(allPrices[i].gold)
          if (!started) { firstX = px; ctx.moveTo(px, py); started = true }
          else { ctx.lineTo(px, py) }
          lastX = px
        }
        ctx.lineTo(lastX, padTop + chartH)
        ctx.lineTo(firstX, padTop + chartH)
        ctx.closePath()
        ctx.fill()

        // 画点
        for (var i = 0; i < n; i++) {
          var px = padLeft + i * stepX
          if (allPrices[i].wti != null) {
            ctx.fillStyle = '#f0a500'
            ctx.beginPath()
            ctx.arc(px, wtiToY(allPrices[i].wti), i === n-1 ? 4 : 3, 0, Math.PI * 2)
            ctx.fill()
          }
          if (allPrices[i].gold != null) {
            ctx.fillStyle = '#58a6ff'
            ctx.beginPath()
            ctx.arc(px, goldToY(allPrices[i].gold), i === n-1 ? 4 : 3, 0, Math.PI * 2)
            ctx.fill()
          }
        }

        // X轴日期标签
        ctx.fillStyle = '#8b949e'
        ctx.font = '10px -apple-system, PingFang SC, sans-serif'
        ctx.textAlign = 'center'
        for (var i = 0; i < n; i++) {
          // 只显示每隔几个
          if (n > 8 && i % 2 !== 0 && i !== n - 1) continue
          var px = padLeft + i * stepX
          ctx.fillText(allPrices[i].date, px, height - 6)
        }

        // 左Y轴标签（WTI）
        ctx.fillStyle = '#f0a500'
        ctx.font = '9px -apple-system, PingFang SC, sans-serif'
        ctx.textAlign = 'right'
        var wtiStep = (wtiMax - wtiMin) / 4
        for (var g = 0; g <= 4; g++) {
          var val = Math.round(wtiMax - g * wtiStep)
          var gy = padTop + chartH * g / 4
          ctx.fillText(val.toString(), padLeft - 4, gy + 3)
        }

        // 右Y轴标签（黄金）
        ctx.fillStyle = '#58a6ff'
        ctx.textAlign = 'left'
        var goldStep = (goldMax - goldMin) / 4
        for (var g = 0; g <= 4; g++) {
          var val = Math.round(goldMax - g * goldStep)
          var gy = padTop + chartH * g / 4
          ctx.fillText(val.toString(), width - padRight + 4, gy + 3)
        }
      })
  },

  savePoster() {
    wx.showToast({ title: '长按截图保存即可', icon: 'none', duration: 2000 })
  },

  copyLink() {
    wx.setClipboardData({
      data: '小程序：霍尔木兹实时追踪（进度条出品）\n打开微信搜索小程序「霍尔木兹实时追踪」',
      success() {
        wx.showToast({ title: '链接已复制', icon: 'success', duration: 1500 })
      }
    })
  },

  trackVisit() {
    const BASE_PV = 6666
    const BASE_UV = 6666
    try {
      let pv = wx.getStorageSync('hormuz_pv') || 0
      let uv = wx.getStorageSync('hormuz_uv') || 0
      const visited = wx.getStorageSync('hormuz_visited')
      pv = pv + 1
      wx.setStorageSync('hormuz_pv', pv)
      if (!visited) {
        uv = uv + 1
        wx.setStorageSync('hormuz_uv', uv)
        wx.setStorageSync('hormuz_visited', true)
      }
      this.setData({
        visitPV: BASE_PV + pv,
        visitUV: BASE_UV + uv
      })
    } catch (e) {
      this.setData({ visitPV: BASE_PV, visitUV: BASE_UV })
    }
  },

  copyWeibo() {
    wx.setClipboardData({
      data: '微博搜索：自由的进度条\nhttps://weibo.com/u/3985879338',
      success() { wx.showToast({ title: '微博地址已复制', icon: 'success' }) }
    })
  },

  copyDouyin() {
    wx.setClipboardData({
      data: '抖音搜索：自由的进度条',
      success() { wx.showToast({ title: '抖音号已复制', icon: 'success' }) }
    })
  },

  copyVideo() {
    wx.setClipboardData({
      data: '视频号搜索：自由的进度条',
      success() { wx.showToast({ title: '视频号已复制', icon: 'success' }) }
    })
  }
})
