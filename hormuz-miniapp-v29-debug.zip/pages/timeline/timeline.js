// pages/timeline/timeline.js
Page({
  data: {
    events: [
      {
        date: '2026-04-08',
        time: '17:30',
        tag: '突发',
        tagColor: 'red',
        title: '美军向波斯湾增派第二艘航母',
        desc: '五角大楼确认林肯号航母战斗群抵达霍尔木兹附近海域，形成双航母压制态势。',
        impact: '油价短线+2.1%',
        impactDir: 'up'
      },
      {
        date: '2026-04-08',
        time: '14:00',
        tag: '外交',
        tagColor: 'blue',
        title: '伊朗拒绝联合国调停方案',
        desc: '德黑兰声明"主权不容谈判"，要求美军先撤出波斯湾再讨论核问题，谈判陷入僵局。',
        impact: '黄金+0.8%',
        impactDir: 'up'
      },
      {
        date: '2026-04-07',
        time: '22:15',
        tag: '军事',
        tagColor: 'orange',
        title: '伊朗无人机逼近美军舰队',
        desc: '美中央司令部报告约20架伊朗察打一体无人机在霍尔木兹海峡附近飞行，未发生直接交火。',
        impact: '原油夜盘+1.5%',
        impactDir: 'up'
      },
      {
        date: '2026-04-07',
        time: '09:00',
        tag: '数据',
        tagColor: 'green',
        title: '霍尔木兹通行油轮降至22艘',
        desc: '较战前日均135艘下降84%，多家船运公司宣布绕行好望角，运费飙升40%。',
        impact: '布伦特+3.2%',
        impactDir: 'up'
      },
      {
        date: '2026-04-06',
        time: '20:00',
        tag: '制裁',
        tagColor: 'purple',
        title: '美国宣布对伊新一轮石油制裁',
        desc: '制裁范围扩大至所有购买伊朗原油的第三国实体，中国、印度买家面临次级制裁压力。',
        impact: '亚洲市场避险情绪升温',
        impactDir: 'neutral'
      },
      {
        date: '2026-04-05',
        time: '11:30',
        tag: '进度条',
        tagColor: 'amber',
        title: '进度条判断：大概率假停火剧本',
        desc: '收割机磨好刀了。川子要面子，老伊要活命，最后时刻各让一步，市场先涨再砸。追高的那块肉是你。',
        impact: '判断记录存档',
        impactDir: 'neutral'
      }
    ]
  },

  onLoad() {}
})
