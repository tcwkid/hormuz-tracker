// pages/chart/chart.js
const app = getApp()

Page({
  data: {
    selectedRange: '7d',
    ranges: [
      { label: '7天', value: '7d' },
      { label: '30天', value: '30d' },
      { label: '90天', value: '90d' }
    ],
    chartPoints: [],
    oilWti: '--',
    oilBrent: '--',
    goldPrice: '--',
    oilWtiChg: 0,
    oilBrentChg: 0,
    goldChg: 0,
    svgPath: '',
    svgGoldPath: '',
    maxPrice: 100,
    minPrice: 60
  },

  onLoad() {
    this.loadChartData('7d')
  },

  onShow() {
    const g = app.globalData
    this.setData({
      oilWti: g.oilPrice?.wti || '--',
      oilBrent: g.oilPrice?.brent || '--',
      goldPrice: g.goldPrice || '--',
      oilWtiChg: 1.2,
      oilBrentChg: 0.9,
      goldChg: -0.3
    })
  },

  switchRange(e) {
    const range = e.currentTarget.dataset.value
    this.setData({ selectedRange: range })
    this.loadChartData(range)
  },

  loadChartData(range) {
    // Mock数据 - 实际接入时替换真实API
    const days = range === '7d' ? 7 : range === '30d' ? 30 : 90
    const oilData = []
    const goldData = []
    let oilBase = 75
    let goldBase = 3300

    for (let i = days; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      const label = `${d.getMonth() + 1}/${d.getDate()}`
      oilBase += (Math.random() - 0.48) * 2
      goldBase += (Math.random() - 0.48) * 30
      oilData.push({ label, value: Math.max(60, Math.min(100, +oilBase.toFixed(1))) })
      goldData.push({ label, value: Math.max(2800, Math.min(4000, +goldBase.toFixed(0))) })
    }

    const oilValues = oilData.map(d => d.value)
    const maxOil = Math.max(...oilValues)
    const minOil = Math.min(...oilValues)

    // 生成SVG折线路径（画布宽680，高200）
    const W = 680, H = 200, PAD = 20
    const xStep = (W - PAD * 2) / (oilData.length - 1)
    const yRange = maxOil - minOil || 10

    let path = ''
    oilData.forEach((pt, i) => {
      const x = PAD + i * xStep
      const y = PAD + (1 - (pt.value - minOil) / yRange) * (H - PAD * 2)
      path += (i === 0 ? `M${x.toFixed(1)},${y.toFixed(1)}` : ` L${x.toFixed(1)},${y.toFixed(1)}`)
    })

    this.setData({
      chartPoints: oilData,
      svgPath: path,
      maxPrice: maxOil.toFixed(1),
      minPrice: minOil.toFixed(1)
    })
  }
})
