// app.js
App({
  globalData: {
    appid: 'wxd90d03669056975a',
    updateInterval: 7200000, // 2小时刷新
    lastUpdate: null,
    shipCount: null,
    oilPrice: null,
    goldPrice: null
  },

  onLaunch() {
    console.log('[霍尔木兹追踪] App启动')
    this.fetchAllData()
  },

  // 全局数据拉取入口
  fetchAllData() {
    const app = this
    // 实际接入时替换为真实API
    // 这里先用mock数据占位
    app.globalData.lastUpdate = new Date().toLocaleString('zh-CN')
    app.globalData.shipCount = 22
    app.globalData.oilPrice = { wti: 75.4, brent: 79.2 }
    app.globalData.goldPrice = 3320
  }
})
